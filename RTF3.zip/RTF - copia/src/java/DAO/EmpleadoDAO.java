/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import ConexionDB.Conexion;
import Modelo.Empleado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Bedoya
 */
public class EmpleadoDAO {
    
    Conexion conexion = new Conexion();
    Connection conexionDB;
    PreparedStatement prepared;
    ResultSet result;
    
    public Empleado validar (String usuario, String contrasena){
        Empleado empleadoValidado = new Empleado();
        String sql = "Select * from empleados where usuario=? and contraseña=?";
        
        try{
            conexionDB = conexion.ConexionDataBase();
            prepared = conexionDB.prepareStatement(sql);
            prepared.setString(1, usuario);
            prepared.setString(2, contrasena);
            result = prepared.executeQuery();
            
            while(result.next()){
                empleadoValidado.setIdEmpleado(result.getString("Id_Empleado"));
                empleadoValidado.setNombre(result.getString("Nombre"));
                empleadoValidado.setCargo(result.getString("Cargo"));
                empleadoValidado.setTelefono(result.getString("Teléfono"));
                empleadoValidado.setUsuario(result.getString("Usuario"));
                empleadoValidado.setContrasena(result.getString("Contraseña"));
                
            }
        }catch(Exception e){
            
        }
        return empleadoValidado;
    }
}

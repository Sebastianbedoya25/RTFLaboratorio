/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Bedoya
 */
public class Conexion {
    
    Connection conexion;
    String url = "jdbc:mysql://localhost:3306/laboratorio?characterEncoding=utf8";//jdbc:mysql://localhost:3306/laboratorio
    String user = "root";
    String password = "SebastianBedoya1997";
    public Connection ConexionDataBase(){
        conexion = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = (Connection) DriverManager.getConnection(url, user, password);
            
        }catch(ClassNotFoundException | SQLException e){
            System.out.println("Error de conexión "+e);
        }
        return conexion;
    }
    
}
